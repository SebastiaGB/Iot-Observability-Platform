import pg8000
import os
import json
from datetime import datetime

def lambda_handler(event, context):
    print("Lambda proces_payload llamada. Evento:", event)

    if isinstance(event, str):
        event = json.loads(event)

    try:
        # Conectar a RDS
        conn = pg8000.connect(
            host=os.environ['DB_HOST'],
            database=os.environ['DB_NAME'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASS'],
            port=5432
        )
        cur = conn.cursor()

        device_id = event["device_id"]
        sensor_type = event["sensor_type"]
        decoded_value = event["decoded_value"]
        timestamp = datetime.utcnow().isoformat()

        cur.execute("""
            INSERT INTO sensor_data (device_id, sensor_type, decoded_value, timestamp_utc)
            VALUES (%s, %s, %s, %s)
        """, (device_id, sensor_type, decoded_value, timestamp))

        conn.commit()
        cur.close()
        conn.close()

        print(f"Datos guardados: {device_id}, {sensor_type}, {decoded_value}, {timestamp}")

        return {"status": "ok", "timestamp": timestamp}

    except Exception as e:
        print("Error en proces_payload:", str(e))
        return {"status": "error", "message": str(e)}
