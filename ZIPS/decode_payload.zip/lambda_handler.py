import boto3
import json
import os

def lambda_handler(event, context):
    try:
        print("Evento recibido:", json.dumps(event))

        body = event.get("body", event)
        if isinstance(body, str):
            body = json.loads(body)

        raw_hex = body.get("payload")
        sensor_type = body.get("sensor_type")
        device_id = body.get("device_id")

        if not raw_hex or not sensor_type or not device_id:
            raise ValueError("Faltan campos obligatorios: payload / sensor_type / device_id")

        value_int = int(raw_hex, 16)
        if sensor_type in ["temperature", "humidity"] and (value_int & 0x8000):
            value_int -= 0x10000

        decoded_value = value_int / 100.0
        print(f"Valor decodificado: {decoded_value}")

        # Invocación síncrona de process_payload
        lambda_client = boto3.client("lambda")
        response = lambda_client.invoke(
            FunctionName=os.environ["PROCESS_LAMBDA_ARN"],  # pasar ARN de la segunda Lambda como variable de entorno
            InvocationType="RequestResponse",  # síncrono
            Payload=json.dumps({
                "device_id": device_id,
                "sensor_type": sensor_type,
                "decoded_value": decoded_value
            })
        )
        print("Response de process_payload:", response)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "status": "ok",
                "decoded_value": decoded_value
            })
        }

    except Exception as e:
        print("❌ Error:", str(e))
        return {
            "statusCode": 400,
            "body": json.dumps({"error": str(e)})
        }
