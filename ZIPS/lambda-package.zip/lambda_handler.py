import os
import psycopg2

def lambda_handler(event, context):
    conn = psycopg2.connect(
        host=os.environ['DB_HOST'],
        database=os.environ['DB_NAME'],
        user=os.environ['DB_USER'],
        password=os.environ['DB_PASS']
    )
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS sensor_data (
            device_id TEXT,
            sensor_type TEXT,
            decoded_value FLOAT,
            timestamp_utc TIMESTAMP
        );
    """)
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "ok", "message": "Tabla sensor_data creada o ya existía"}
